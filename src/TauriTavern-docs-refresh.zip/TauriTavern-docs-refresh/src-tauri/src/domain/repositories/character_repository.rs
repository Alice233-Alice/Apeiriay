use crate::domain::errors::DomainError;
use crate::domain::models::character::Character;
use async_trait::async_trait;
use std::path::Path;

pub const CHARACTER_CREATE_WARNING_AVATAR_IMPORT_FAILED: &str = "avatar-import-failed";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CharacterCreateWarning {
    pub code: String,
    pub message: String,
}

#[derive(Debug, Clone)]
pub struct CharacterCreateResult {
    pub character: Character,
    pub warnings: Vec<CharacterCreateWarning>,
}

/// Repository interface for character management
#[async_trait]
pub trait CharacterRepository: Send + Sync {
    /// Save a character to the repository
    async fn save(&self, character: &Character) -> Result<(), DomainError>;

    /// Find a character by its file name (without extension)
    async fn find_by_name(&self, name: &str) -> Result<Character, DomainError>;

    /// Find all characters in the repository
    async fn find_all(&self, shallow: bool) -> Result<Vec<Character>, DomainError>;

    /// List stored character avatar filenames without reading card metadata.
    async fn list_avatar_filenames(&self) -> Result<Vec<String>, DomainError>;

    /// Delete a character by its file name (without extension)
    async fn delete(&self, name: &str, delete_chats: bool) -> Result<(), DomainError>;

    /// Update an existing character
    async fn update(&self, character: &Character) -> Result<(), DomainError>;

    /// Persist raw character card JSON into the existing character file.
    async fn write_character_card_json(
        &self,
        name: &str,
        character_card_json: &str,
        avatar_path: Option<&Path>,
        crop: Option<ImageCrop>,
    ) -> Result<Character, DomainError>;

    /// Rename a character
    async fn rename(&self, old_name: &str, new_name: &str) -> Result<Character, DomainError>;

    /// Duplicate a character card file from the stored source PNG bytes.
    async fn duplicate(&self, name: &str) -> Result<Character, DomainError>;

    /// Import a character from a file
    async fn import_character(
        &self,
        file_path: &Path,
        preserve_file_name: Option<String>,
    ) -> Result<Character, DomainError>;

    /// Export a character card to a target path without mutating the stored source file.
    async fn export_character(
        &self,
        name: &str,
        target_path: &Path,
        character_card_json: &str,
    ) -> Result<(), DomainError>;

    /// Read the raw character card JSON payload as stored (PNG metadata, preferring V3 when available).
    async fn read_character_card_json(&self, name: &str) -> Result<String, DomainError>;

    /// Export a character card as PNG bytes by writing supplied card JSON metadata.
    async fn export_character_png_bytes(
        &self,
        name: &str,
        character_card_json: &str,
    ) -> Result<Vec<u8>, DomainError>;

    /// Create a character with an avatar image
    async fn create_with_avatar(
        &self,
        character: &Character,
        avatar_path: Option<&Path>,
        crop: Option<ImageCrop>,
    ) -> Result<CharacterCreateResult, DomainError>;

    /// Update a character's avatar
    async fn update_avatar(
        &self,
        character: &Character,
        avatar_path: &Path,
        crop: Option<ImageCrop>,
    ) -> Result<(), DomainError>;

    /// Get character chats
    async fn get_character_chats(
        &self,
        name: &str,
        simple: bool,
    ) -> Result<Vec<CharacterChat>, DomainError>;

    /// Clear the character cache
    async fn clear_cache(&self) -> Result<(), DomainError>;
}

/// Image crop parameters
#[derive(Debug, Clone)]
pub struct ImageCrop {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    pub want_resize: bool,
}

/// Character chat information
#[derive(Debug, Clone)]
pub struct CharacterChat {
    pub file_name: String,
    pub file_size: String,
    pub chat_items: usize,
    pub last_message: String,
    pub last_message_date: i64,
}
